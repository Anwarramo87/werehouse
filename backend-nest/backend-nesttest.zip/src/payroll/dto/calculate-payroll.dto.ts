import { IsDateString, IsNumber, IsOptional, IsBoolean } from 'class-validator';

export class CalculatePayrollDto {
  @IsDateString()
  periodStart: string;

  @IsDateString()
  periodEnd: string;

  @IsOptional()
  @IsNumber()
  gracePeriodMinutes?: number;

  @IsOptional()
  @IsNumber()
  workDaysInPeriod?: number;

  @IsOptional()
  @IsNumber()
  hoursPerDay?: number;

  @IsOptional()
  @IsBoolean()
  includeAttendanceDeductions?: boolean;

  @IsOptional()
  @IsBoolean()
  includeTransportationDeductions?: boolean;
}
