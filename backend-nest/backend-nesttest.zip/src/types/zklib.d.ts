declare module 'zklib';
